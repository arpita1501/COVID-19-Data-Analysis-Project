
import React, { useEffect, useState } from 'react';
import Papa from 'papaparse';
import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from 'recharts';

function App() {
  const [data, setData] = useState([]);
  const [states, setStates] = useState([]);
  const [selectedState, setSelectedState] = useState("All India");

  useEffect(() => {
    Papa.parse('/covid_data.csv', {
      header: true,
      download: true,
      complete: (results) => {
        const cleaned = results.data.filter(row =>
          row.date && row.confirmed && row.cured && row.deaths
        ).map(row => ({
          Date: row.date,
          State: row["state/unionterritory"],
          Confirmed: Number(row.confirmed),
          Recovered: Number(row.cured),
          Deaths: Number(row.deaths)
        }));

        setData(cleaned);

        const stateList = [...new Set(cleaned.map(item => item.State))];
        setStates(["All India", ...stateList]);
      }
    });
  }, []);

  const filteredData = selectedState === "All India"
    ? data
    : data.filter(item => item.State === selectedState);

  const latestDate = data.length ? data[data.length - 1].Date : null;

  const latestData = data.filter(item => item.Date === latestDate);
  const topStates = [...new Set(latestData.map(item => item.State))]
    .map(state => {
      const stateData = latestData.find(item => item.State === state);
      return {
        State: state,
        Confirmed: stateData ? stateData.Confirmed : 0
      };
    })
    .sort((a, b) => b.Confirmed - a.Confirmed)
    .slice(0, 5);

  const latestSelectedData = filteredData.filter(item => item.Date === latestDate);
  const totalConfirmed = latestSelectedData.reduce((sum, item) => sum + item.Confirmed, 0);
  const totalRecovered = latestSelectedData.reduce((sum, item) => sum + item.Recovered, 0);
  const totalDeaths = latestSelectedData.reduce((sum, item) => sum + item.Deaths, 0);

  const pieData = [
    { name: 'Confirmed', value: totalConfirmed },
    { name: 'Recovered', value: totalRecovered },
    { name: 'Deaths', value: totalDeaths }
  ];

  const COLORS = ['#1D4ED8', '#10B981', '#EF4444'];

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-4">COVID-19 India Dashboard</h1>

      <div className="mb-4">
        <label className="mr-2 font-medium">Select State:</label>
        <select
          value={selectedState}
          onChange={(e) => setSelectedState(e.target.value)}
          className="border rounded p-1"
        >
          {states.map(state => (
            <option key={state} value={state}>{state}</option>
          ))}
        </select>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-blue-100 p-4 rounded shadow text-center">
          <h3 className="text-xl font-semibold">Confirmed</h3>
          <p className="text-2xl font-bold text-blue-800">{totalConfirmed}</p>
        </div>
        <div className="bg-green-100 p-4 rounded shadow text-center">
          <h3 className="text-xl font-semibold">Recovered</h3>
          <p className="text-2xl font-bold text-green-800">{totalRecovered}</p>
        </div>
        <div className="bg-red-100 p-4 rounded shadow text-center">
          <h3 className="text-xl font-semibold">Deaths</h3>
          <p className="text-2xl font-bold text-red-800">{totalDeaths}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

        {/* Line Chart */}
        <div className="bg-white shadow rounded p-4">
          <h2 className="text-xl font-semibold mb-2">Trend Over Time</h2>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={filteredData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="Date" tick={{ fontSize: 10 }} />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="Confirmed" stroke="#1D4ED8" />
              <Line type="monotone" dataKey="Recovered" stroke="#10B981" />
              <Line type="monotone" dataKey="Deaths" stroke="#EF4444" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Top 5 States Bar Chart */}
        <div className="bg-white shadow rounded p-4">
          <h2 className="text-xl font-semibold mb-2">Top 5 States (Confirmed)</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={topStates}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="State" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="Confirmed" fill="#1D4ED8" />
            </BarChart>
          </ResponsiveContainer>
        </div>

      </div>

      {/* Pie Chart */}
      <div className="bg-white shadow rounded p-4 mt-6">
        <h2 className="text-xl font-semibold mb-2">Latest Case Distribution</h2>
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label>
              {pieData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </div>

    </div>
  );
}

export default App;
